# notebook
平常学习记录

1.docker 容器，初始化各个组件