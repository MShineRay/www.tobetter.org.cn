# JVM 学习 笔记

## 常见问题

```
1.jvm运行时数据区
2.垃圾回收算法
3.jvm内存模型jmm
4.内存泄漏与内存溢出的区别
5.Java 内存分配策略？多个线程同时请求内存，如何分配？
```

### 优化

```
-XX:+UseConcMarkSweepGC   -XX:SurvivorRatio=8
```



